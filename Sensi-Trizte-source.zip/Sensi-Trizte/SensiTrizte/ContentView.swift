import SwiftUI

private enum ST {
    static let bg = Color(red: 0.025, green: 0.03, blue: 0.045)
    static let panel = Color(red: 0.075, green: 0.085, blue: 0.105)
    static let muted = Color(red: 0.52, green: 0.56, blue: 0.62)
    static let cyan = Color(red: 0.22, green: 0.88, blue: 0.94)
    static let violet = Color(red: 0.62, green: 0.36, blue: 0.98)
}

struct ContentView: View {
    @State private var tab = 0
    @State private var selectedPreset = "FF NORMAL"
    @State private var sensitivity: Double = 78
    @State private var redDot: Double = 65
    @State private var general: Double = 92
    @State private var scope: Double = 84
    @State private var saved = false

    private let tabs = ["Home", "Sensi", "Stats", "Session"]
    private let icons = ["house.fill", "scope", "chart.bar.fill", "clock.fill"]

    var body: some View {
        ZStack {
            ST.bg.ignoresSafeArea()
            VStack(spacing: 0) {
                header
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 18) {
                        if tab == 0 { homePage }
                        else if tab == 1 { sensiPage }
                        else if tab == 2 { statsPage }
                        else { sessionPage }
                    }
                    .padding(.horizontal, 18)
                    .padding(.top, 16)
                    .padding(.bottom, 28)
                }
                bottomBar
            }
        }
        .preferredColorScheme(.dark)
    }

    private var header: some View {
        HStack(spacing: 11) {
            ZStack {
                RoundedRectangle(cornerRadius: 12).fill(
                    LinearGradient(colors: [ST.cyan.opacity(0.9), ST.violet], startPoint: .topLeading, endPoint: .bottomTrailing)
                )
                Image(systemName: "bolt.fill").font(.system(size: 19, weight: .black)).foregroundStyle(.black)
            }
            .frame(width: 39, height: 39)
            VStack(alignment: .leading, spacing: 1) {
                Text("SENSI TRIZTE").font(.system(size: 15, weight: .black, design: .rounded)).tracking(1.8)
                Text("CONTROL CENTER  •  V1.0").font(.system(size: 8, weight: .bold, design: .monospaced)).tracking(1.1).foregroundStyle(ST.muted)
            }
            Spacer()
            Circle().fill(Color.green).frame(width: 6, height: 6)
            Text("ONLINE").font(.system(size: 9, weight: .bold, design: .monospaced)).foregroundStyle(ST.muted)
            Image(systemName: "ellipsis").foregroundStyle(.white.opacity(0.8)).padding(.leading, 8)
        }
        .padding(.horizontal, 18).padding(.vertical, 12)
        .background(ST.panel.opacity(0.78))
        .overlay(alignment: .bottom) { Rectangle().fill(.white.opacity(0.07)).frame(height: 1) }
    }

    private var homePage: some View {
        VStack(alignment: .leading, spacing: 17) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("BIENVENIDO").font(.system(size: 10, weight: .bold, design: .monospaced)).tracking(2).foregroundStyle(ST.cyan)
                    Text("Tu espacio.\nTu configuración.").font(.system(size: 29, weight: .black, design: .rounded))
                }
                Spacer()
                Image(systemName: "scope").font(.system(size: 55, weight: .ultraLight)).foregroundStyle(ST.cyan.opacity(0.8))
            }
            heroCard
            HStack(spacing: 10) {
                metric("PERFILES", value: "04", icon: "square.stack.3d.up")
                metric("AJUSTES", value: "12", icon: "slider.horizontal.3")
                metric("ESTADO", value: "OK", icon: "checkmark.shield")
            }
            sectionTitle("PERFILES DESTACADOS", action: "VER TODOS")
            presetCard("FF NORMAL", subtitle: "Equilibrado · uso general", symbol: "circle.grid.2x2")
            presetCard("PRECISIÓN", subtitle: "Ajustes suaves y controlados", symbol: "scope")
            noteCard
        }
    }

    private var heroCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Label("CONFIGURACIÓN ACTIVA", systemImage: "waveform.path").font(.system(size: 9, weight: .bold, design: .monospaced)).tracking(1)
                Spacer()
                Text("PRESET 01").font(.system(size: 8, weight: .bold, design: .monospaced)).foregroundStyle(ST.cyan)
            }.foregroundStyle(ST.muted)
            Text(selectedPreset).font(.system(size: 25, weight: .black, design: .rounded))
            Text("Un perfil limpio para organizar tus preferencias de sensibilidad.").font(.system(size: 12)).foregroundStyle(.white.opacity(0.62))
            Button { tab = 1 } label: {
                HStack { Text("EDITAR SENSI"); Spacer(); Image(systemName: "arrow.up.right") }
                    .font(.system(size: 10, weight: .black, design: .monospaced)).tracking(1)
                    .foregroundStyle(.black).padding(14).background(LinearGradient(colors: [ST.cyan, Color(red: 0.43, green: 0.76, blue: 1)], startPoint: .leading, endPoint: .trailing), in: RoundedRectangle(cornerRadius: 12))
            }
        }
        .padding(18)
        .background {
            RoundedRectangle(cornerRadius: 20).fill(
                LinearGradient(colors: [ST.violet.opacity(0.25), ST.panel, ST.panel], startPoint: .topTrailing, endPoint: .bottomLeading)
            )
            RoundedRectangle(cornerRadius: 20).stroke(.white.opacity(0.1), lineWidth: 1)
        }
    }

    private var sensiPage: some View {
        VStack(alignment: .leading, spacing: 17) {
            pageHeading("Sensi", subtitle: "AJUSTA Y GUARDA TUS PREFERENCIAS")
            HStack(spacing: 8) {
                presetChip("FF NORMAL")
                presetChip("PRECISIÓN")
                presetChip("PERSONAL")
            }
            VStack(spacing: 18) {
                sliderRow("GENERAL", value: $general)
                sliderRow("PUNTO ROJO", value: $redDot)
                sliderRow("MIRA 2X", value: $sensitivity)
                sliderRow("MIRA 4X", value: $scope)
            }
            .padding(17).background(ST.panel, in: RoundedRectangle(cornerRadius: 18))
            Button {
                saved = true
                selectedPreset = "PERSONAL"
            } label: {
                Label(saved ? "CONFIGURACIÓN GUARDADA" : "GUARDAR CONFIGURACIÓN", systemImage: saved ? "checkmark.circle.fill" : "square.and.arrow.down.fill")
                    .font(.system(size: 10, weight: .black, design: .monospaced)).tracking(1)
                    .frame(maxWidth: .infinity).padding(16)
                    .background(ST.cyan, in: RoundedRectangle(cornerRadius: 13)).foregroundStyle(.black)
            }
            Text("Estos valores son preferencias guardadas dentro de la app; no modifican archivos ni memoria de otros juegos.")
                .font(.system(size: 10)).foregroundStyle(ST.muted).padding(.horizontal, 3)
        }
    }

    private var statsPage: some View {
        VStack(alignment: .leading, spacing: 17) {
            pageHeading("Stats", subtitle: "RESUMEN LOCAL DE TU CONFIGURACIÓN")
            metric("PERFILES GUARDADOS", value: "04", icon: "square.stack.3d.up")
            metric("ÚLTIMA MODIFICACIÓN", value: "HOY", icon: "calendar")
            metric("ESTADO DE LA APP", value: "ESTABLE", icon: "checkmark.shield")
            VStack(alignment: .leading, spacing: 12) {
                sectionTitle("ACTIVIDAD RECIENTE", action: "LOCAL")
                activity("Perfil FF NORMAL seleccionado", time: "RECIENTE")
                activity("Panel de sensibilidad abierto", time: "HOY")
                activity("Sensi Trizte iniciado", time: "HOY")
            }.padding(17).background(ST.panel, in: RoundedRectangle(cornerRadius: 18))
        }
    }

    private var sessionPage: some View {
        VStack(alignment: .leading, spacing: 17) {
            pageHeading("Session", subtitle: "ESTADO DE ESTA SESIÓN")
            VStack(spacing: 15) {
                Image(systemName: "timer").font(.system(size: 42, weight: .ultraLight)).foregroundStyle(ST.cyan)
                Text("SESIÓN ACTIVA").font(.system(size: 19, weight: .black, design: .rounded))
                Text("00:24:18").font(.system(size: 30, weight: .bold, design: .monospaced)).foregroundStyle(ST.cyan)
                Text("El contador es ilustrativo y funciona solo dentro de Sensi Trizte.").font(.system(size: 11)).foregroundStyle(ST.muted).multilineTextAlignment(.center)
            }
            .frame(maxWidth: .infinity).padding(25).background(ST.panel, in: RoundedRectangle(cornerRadius: 20))
            noteCard
        }
    }

    private var noteCard: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "info.circle.fill").foregroundStyle(ST.cyan)
            Text("Sensi Trizte es un panel independiente para guardar y organizar ajustes. No inyecta código ni altera juegos o dispositivos.")
                .font(.system(size: 10)).foregroundStyle(ST.muted)
        }.padding(14).background(.white.opacity(0.035), in: RoundedRectangle(cornerRadius: 13))
    }

    private var bottomBar: some View {
        HStack(spacing: 0) {
            ForEach(0..<tabs.count, id: \.self) { i in
                Button { withAnimation(.easeInOut(duration: 0.18)) { tab = i } } label: {
                    VStack(spacing: 5) {
                        Image(systemName: icons[i]).font(.system(size: 15, weight: .semibold))
                        Text(tabs[i].uppercased()).font(.system(size: 8, weight: .black, design: .monospaced)).tracking(0.7)
                    }
                    .foregroundStyle(tab == i ? ST.cyan : ST.muted)
                    .frame(maxWidth: .infinity).padding(.vertical, 13)
                    .background(tab == i ? ST.cyan.opacity(0.08) : .clear, in: RoundedRectangle(cornerRadius: 12))
                }
            }
        }
        .padding(.horizontal, 10).padding(.top, 8)
        .background(ST.panel)
        .overlay(alignment: .top) { Rectangle().fill(.white.opacity(0.08)).frame(height: 1) }
    }

    private func metric(_ title: String, value: String, icon: String) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Image(systemName: icon).foregroundStyle(ST.cyan).font(.system(size: 14))
            Text(value).font(.system(size: 18, weight: .black, design: .rounded))
            Text(title).font(.system(size: 7, weight: .bold, design: .monospaced)).foregroundStyle(ST.muted).tracking(0.5)
        }
        .frame(maxWidth: .infinity, alignment: .leading).padding(13)
        .background(ST.panel, in: RoundedRectangle(cornerRadius: 14))
    }

    private func sectionTitle(_ title: String, action: String) -> some View {
        HStack {
            Text(title).font(.system(size: 10, weight: .black, design: .monospaced)).tracking(1.2)
            Spacer()
            Text(action).font(.system(size: 8, weight: .bold, design: .monospaced)).foregroundStyle(ST.cyan)
        }
    }

    private func presetCard(_ title: String, subtitle: String, symbol: String) -> some View {
        Button {
            selectedPreset = title
            tab = 1
        } label: {
            HStack(spacing: 13) {
                Image(systemName: symbol).font(.system(size: 20)).foregroundStyle(ST.cyan).frame(width: 42, height: 42).background(ST.cyan.opacity(0.1), in: RoundedRectangle(cornerRadius: 12))
                VStack(alignment: .leading, spacing: 4) {
                    Text(title).font(.system(size: 13, weight: .black, design: .rounded)).foregroundStyle(.white)
                    Text(subtitle).font(.system(size: 10)).foregroundStyle(ST.muted)
                }
                Spacer()
                Image(systemName: "chevron.right").font(.system(size: 10, weight: .bold)).foregroundStyle(ST.muted)
            }.padding(13).background(ST.panel, in: RoundedRectangle(cornerRadius: 15))
        }
    }

    private func presetChip(_ name: String) -> some View {
        Button { selectedPreset = name } label: {
            Text(name).font(.system(size: 8, weight: .black, design: .monospaced))
                .foregroundStyle(selectedPreset == name ? .black : ST.muted)
                .padding(.horizontal, 10).padding(.vertical, 9)
                .background(selectedPreset == name ? ST.cyan : ST.panel, in: Capsule())
        }
    }

    private func sliderRow(_ title: String, value: Binding<Double>) -> some View {
        VStack(spacing: 8) {
            HStack {
                Text(title).font(.system(size: 9, weight: .bold, design: .monospaced)).tracking(1).foregroundStyle(ST.muted)
                Spacer()
                Text("\(Int(value.wrappedValue))").font(.system(size: 12, weight: .black, design: .monospaced)).foregroundStyle(ST.cyan)
            }
            Slider(value: value, in: 0...100).tint(ST.cyan)
        }
    }

    private func pageHeading(_ title: String, subtitle: String) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title).font(.system(size: 31, weight: .black, design: .rounded))
            Text(subtitle).font(.system(size: 8, weight: .bold, design: .monospaced)).tracking(1.2).foregroundStyle(ST.muted)
        }
    }

    private func activity(_ title: String, time: String) -> some View {
        HStack(spacing: 9) {
            Circle().fill(ST.cyan).frame(width: 6, height: 6)
            Text(title).font(.system(size: 10)).foregroundStyle(.white.opacity(0.8))
            Spacer()
            Text(time).font(.system(size: 7, weight: .bold, design: .monospaced)).foregroundStyle(ST.muted)
        }
    }
}
