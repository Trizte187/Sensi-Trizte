# Sensi Trizte

Proyecto iOS SwiftUI con estilo oscuro/neón inspirado en el video de referencia.

## Incluye
- Inicio con perfiles destacados
- Panel Sensi con controles deslizantes y guardado visual de preferencias
- Estadísticas locales ilustrativas
- Pantalla de sesión
- Flujo GitHub Actions para compilar una IPA sin firmar

## Compilar en GitHub
1. Crea un repositorio nuevo en GitHub.
2. Sube el contenido completo de este ZIP (incluida la carpeta oculta `.github`).
3. Abre la pestaña **Actions**.
4. Ejecuta **Build unsigned IPA** con **Run workflow**.
5. Descarga el artefacto `Sensi-Trizte-unsigned-IPA`.

## Importante
La app es un panel independiente de ajustes guardados localmente. No modifica memoria, archivos ni procesos de juegos, y no incluye cheats, inyección ni automatización de apuntado. La IPA se genera en GitHub Actions; este entorno no dispone de Xcode para compilarla directamente.
